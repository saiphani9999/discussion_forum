# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from .forms import *
from django.shortcuts import render, HttpResponseRedirect, reverse
from django.contrib.auth import login, authenticate
from django.views import generic


# Create your views here.
def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)

        if user:
            login(request, user)
            return HttpResponseRedirect(reverse('accounts:question-list'))

    else:
        user_form = UserForm()
        return render(request, 'accounts/login.html', {'user_form': user_form})


def comment(request):
    if request.method == 'POST':
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comments = comment_form.save()
            comments.save()
            return HttpResponseRedirect(reverse('accounts:question-list'))

        else:
            print (comment_form.errors)
            return HttpResponseRedirect(reverse('accounts:question-list'))

    else:
        comment_form = CommentForm()
        return render(request, 'accounts/QuestionList.html', {'comment_form':comment_form})


class SubjectList(generic.ListView):
    model = Subject
    template_name = 'accounts/QuestionList.html'
    context_object_name = 'subs'

    def get_queryset(self):
        return Subject.objects.all()


def questions(request,pk):
    ques = Thread.objects.filter(subject=pk)
    args = {'ques':ques}
    return render(request,'accounts/QuestionList.html',args)


def comments(request,pk):
    lists = Comment.objects.filter(thread=pk)
    args = {'lists':lists}
    return render(request, 'accounts/QuestionList.html', args)

