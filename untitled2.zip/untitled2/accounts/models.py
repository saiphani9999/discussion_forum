# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib.auth.models import User
from django.utils import timezone
from django.db import models

# Create your models here.


class CustomUser(models.Model):
    user = models.OneToOneField(User)

    def __str__(self):
        return self.user.username


class Subject(models.Model):
    subject_name = models.CharField(max_length=50)

    def __str__(self):
        return self.subject_name


class Thread(models.Model):
    question = models.CharField(max_length=500)
    timestamp = models.DateTimeField(default=timezone.now())
    subject = models.ForeignKey(Subject)
    user = models.ForeignKey(CustomUser)

    def __str__(self):
        return self.question


class Comment(models.Model):
    content = models.CharField(max_length=1000)
    timestamp = models.DateTimeField(default=timezone.now())
    thread = models.ForeignKey(Thread)
    user = models.ForeignKey(CustomUser)

    def __str__(self):
        return self.user.user.username

