from django.conf.urls import url , include
from . import views
from django.views.generic import TemplateView

app_name = 'accounts'

urlpatterns = [
    url(r'^login/$',views.user_login, name='login' ),
    url(r'^QuestionList/$', views.SubjectList.as_view(), name='question-list'),
    url(r'^questions/(?P<pk>\d+)/$',views.questions, name='questions'),
    url(r'^comments/(?P<pk>\d+)/$',views.comments, name='comments'),
    url(r'^comment/$',views.comment, name='comment'),

]